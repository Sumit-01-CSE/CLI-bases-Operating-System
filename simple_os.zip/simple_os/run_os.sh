#!/bin/bash

# Simple OS Runner Script
echo "Starting Simple OS in QEMU..."
echo "Press Ctrl+A then X to exit QEMU"
echo ""

# Kill any existing QEMU processes
pkill -f qemu 2>/dev/null

# Run QEMU
qemu-system-i386 \
    -drive file=build/os.img,format=raw,if=floppy \
    -display curses \
    -no-reboot \
    -no-shutdown \
    -monitor stdio
