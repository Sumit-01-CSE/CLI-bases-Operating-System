#!/bin/bash

# Verification script for Simple OS
echo "=== Simple OS Verification ==="
echo ""

# Check if build directory exists
if [ -d "build" ]; then
    echo "✓ Build directory exists"
else
    echo "✗ Build directory missing"
    exit 1
fi

# Check if bootloader exists
if [ -f "build/boot.bin" ]; then
    echo "✓ Bootloader (boot.bin) exists"
    echo "  Size: $(wc -c < build/boot.bin) bytes"
else
    echo "✗ Bootloader missing"
    exit 1
fi

# Check if kernel exists
if [ -f "build/kernel.bin" ]; then
    echo "✓ Kernel (kernel.bin) exists"
    echo "  Size: $(wc -c < build/kernel.bin) bytes"
else
    echo "✗ Kernel missing"
    exit 1
fi

# Check if OS image exists
if [ -f "build/os.img" ]; then
    echo "✓ OS image (os.img) exists"
    echo "  Size: $(wc -c < build/os.img) bytes"
else
    echo "✗ OS image missing"
    exit 1
fi

# Check bootloader signature
if hexdump -C build/boot.bin | tail -2 | head -1 | grep -q "55 aa"; then
    echo "✓ Bootloader has correct boot signature (0x55AA)"
else
    echo "✗ Bootloader missing boot signature"
fi

echo ""
echo "=== Build Verification Complete ==="
echo "To run the OS: make run"
echo "Or use: ./test_os.sh"
