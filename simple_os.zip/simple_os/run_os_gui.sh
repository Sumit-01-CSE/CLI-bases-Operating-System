#!/bin/bash

# Simple OS Runner Script with GUI
echo "Starting Simple OS in QEMU with GUI..."
echo "Press Ctrl+Alt+G to release mouse/keyboard from QEMU"
echo ""

# Kill any existing QEMU processes
pkill -f qemu 2>/dev/null

# Run QEMU with GUI
qemu-system-i386 \
    -drive file=build/os.img,format=raw,if=floppy \
    -display cocoa \
    -no-reboot \
    -no-shutdown
