# Simple OS

A minimal operating system that runs on QEMU emulator with a proper bootloader and kernel.

## Features

- **Bootloader**: Simple 16-bit bootloader that loads the kernel and switches to protected mode
- **Kernel**: Basic 32-bit kernel with essential functions
- **VGA Text Mode**: Full VGA text mode support with colors
- **Memory Management**: Basic memory layout and management
- **System Functions**: Print, string manipulation, and delay functions

## Project Structure

```
simple_os/
├── boot/
│   └── boot.asm          # Bootloader (16-bit assembly)
├── kernel/
│   ├── kernel.c          # Main kernel code (C)
│   ├── kernel.h          # Kernel header file
│   ├── start.asm         # Kernel entry point (32-bit assembly)
│   └── linker.ld         # Linker script
├── Makefile              # Build system
└── README.md             # This file
```

## Requirements

- **NASM**: Netwide Assembler
- **GCC**: GNU Compiler Collection (with 32-bit support)
- **QEMU**: Emulator for running the OS
- **Make**: Build system

### macOS Installation

```bash
brew install nasm qemu
```

## Building and Running

1. **Build the OS**:
   ```bash
   make all
   ```

2. **Run in QEMU**:
   ```bash
   make run
   ```

3. **Run with debugger**:
   ```bash
   make debug
   ```

4. **Clean build files**:
   ```bash
   make clean
   ```

## How It Works

### Boot Process

1. **BIOS**: Loads the bootloader from the first sector of the disk
2. **Bootloader**: 
   - Sets up segments and stack
   - Loads the kernel from disk sectors 2-5
   - Switches to protected mode
   - Jumps to the kernel at address 0x1000
3. **Kernel**:
   - Initializes the system
   - Sets up VGA text mode
   - Runs the main kernel loop

### Memory Layout

- **0x0000-0x03FF**: Interrupt Vector Table
- **0x0400-0x04FF**: BIOS Data Area
- **0x0500-0x7BFF**: Free memory
- **0x7C00-0x7DFF**: Bootloader (512 bytes)
- **0x7E00-0x9FFF**: Free memory
- **0x1000-0x1FFF**: Kernel (loaded by bootloader)
- **0xB8000-0xBFFFF**: VGA Text Mode Buffer

## Kernel Features

- **VGA Text Mode**: 80x25 character display with 16 colors
- **Print Functions**: `print_char()`, `print_string()`, `print_number()`
- **Memory Functions**: `memcpy()`, `memset()`, `strlen()`
- **System Functions**: `clear_screen()`, `delay()`

## Customization

You can extend the kernel by:

1. Adding new functions to `kernel.c`
2. Implementing interrupt handlers
3. Adding file system support
4. Implementing process management
5. Adding hardware drivers

## Troubleshooting

### Build Errors

- **NASM not found**: Install NASM using `brew install nasm`
- **GCC 32-bit error**: Install 32-bit GCC support
- **QEMU not found**: Install QEMU using `brew install qemu`

### Runtime Issues

- **Black screen**: Check if the kernel is being loaded correctly
- **Garbage on screen**: Verify VGA buffer initialization
- **System hangs**: Check for infinite loops in kernel code

## License

This project is for educational purposes. Feel free to use and modify as needed.
