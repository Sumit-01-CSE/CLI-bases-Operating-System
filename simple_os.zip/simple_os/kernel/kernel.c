// Simple OS Kernel
// Basic kernel with essential functions

#include "kernel.h"

// VGA buffer address
volatile char* vga_buffer = (volatile char*)0xB8000;

// Current cursor position
int cursor_x = 0;
int cursor_y = 0;

// Color constants
#define VGA_COLOR_BLACK 0
#define VGA_COLOR_BLUE 1
#define VGA_COLOR_GREEN 2
#define VGA_COLOR_CYAN 3
#define VGA_COLOR_RED 4
#define VGA_COLOR_MAGENTA 5
#define VGA_COLOR_BROWN 6
#define VGA_COLOR_LIGHT_GREY 7
#define VGA_COLOR_DARK_GREY 8
#define VGA_COLOR_LIGHT_BLUE 9
#define VGA_COLOR_LIGHT_GREEN 10
#define VGA_COLOR_LIGHT_CYAN 11
#define VGA_COLOR_LIGHT_RED 12
#define VGA_COLOR_LIGHT_MAGENTA 13
#define VGA_COLOR_YELLOW 14
#define VGA_COLOR_WHITE 15

// VGA dimensions
#define VGA_WIDTH 80
#define VGA_HEIGHT 25

// Clear screen
void clear_screen() {
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        vga_buffer[i * 2] = ' ';
        vga_buffer[i * 2 + 1] = (VGA_COLOR_LIGHT_GREY << 4) | VGA_COLOR_BLACK;
    }
    cursor_x = 0;
    cursor_y = 0;
}

// Print a character
void print_char(char c, int color) {
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else if (c == '\r') {
        cursor_x = 0;
    } else {
        int index = (cursor_y * VGA_WIDTH + cursor_x) * 2;
        vga_buffer[index] = c;
        vga_buffer[index + 1] = color;
        cursor_x++;
    }
    
    // Handle line wrapping
    if (cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }
    
    // Handle screen scrolling
    if (cursor_y >= VGA_HEIGHT) {
        // Scroll screen up
        for (int i = 0; i < (VGA_HEIGHT - 1) * VGA_WIDTH; i++) {
            vga_buffer[i * 2] = vga_buffer[(i + VGA_WIDTH) * 2];
            vga_buffer[i * 2 + 1] = vga_buffer[(i + VGA_WIDTH) * 2 + 1];
        }
        // Clear last line
        for (int i = (VGA_HEIGHT - 1) * VGA_WIDTH; i < VGA_HEIGHT * VGA_WIDTH; i++) {
            vga_buffer[i * 2] = ' ';
            vga_buffer[i * 2 + 1] = (VGA_COLOR_LIGHT_GREY << 4) | VGA_COLOR_BLACK;
        }
        cursor_y = VGA_HEIGHT - 1;
    }
}

// Print a string
void print_string(const char* str, int color) {
    while (*str) {
        print_char(*str, color);
        str++;
    }
}

// Print a number
void print_number(int num, int color) {
    if (num == 0) {
        print_char('0', color);
        return;
    }
    
    char buffer[32];
    int i = 0;
    int is_negative = 0;
    
    if (num < 0) {
        is_negative = 1;
        num = -num;
    }
    
    while (num > 0) {
        buffer[i++] = '0' + (num % 10);
        num /= 10;
    }
    
    if (is_negative) {
        buffer[i++] = '-';
    }
    
    // Reverse the string
    for (int j = i - 1; j >= 0; j--) {
        print_char(buffer[j], color);
    }
}

// Simple memory copy function
void* memcpy(void* dest, const void* src, int n) {
    char* d = (char*)dest;
    const char* s = (const char*)src;
    for (int i = 0; i < n; i++) {
        d[i] = s[i];
    }
    return dest;
}

// Simple memory set function
void* memset(void* s, int c, int n) {
    char* p = (char*)s;
    for (int i = 0; i < n; i++) {
        p[i] = c;
    }
    return s;
}

// String length function
int strlen(const char* str) {
    int len = 0;
    while (str[len]) {
        len++;
    }
    return len;
}

// Simple delay function
void delay(int count) {
    for (int i = 0; i < count; i++) {
        for (int j = 0; j < 1000; j++) {
            // Simple delay loop
        }
    }
}

// Kernel main function
void kernel_main() {
    // Clear screen
    clear_screen();
    
    // Print welcome message
    print_string("Simple OS Kernel Started Successfully!", 
                 (VGA_COLOR_LIGHT_GREEN << 4) | VGA_COLOR_BLACK);
    print_char('\n', 0);
    print_char('\n', 0);
    
    // Print system information
    print_string("System Information:", 
                 (VGA_COLOR_LIGHT_CYAN << 4) | VGA_COLOR_BLACK);
    print_char('\n', 0);
    
    print_string("- VGA Text Mode: 80x25", 
                 (VGA_COLOR_LIGHT_GREY << 4) | VGA_COLOR_BLACK);
    print_char('\n', 0);
    
    print_string("- Memory Layout: Kernel at 0x1000", 
                 (VGA_COLOR_LIGHT_GREY << 4) | VGA_COLOR_BLACK);
    print_char('\n', 0);
    
    print_string("- Protected Mode: Enabled", 
                 (VGA_COLOR_LIGHT_GREY << 4) | VGA_COLOR_BLACK);
    print_char('\n', 0);
    print_char('\n', 0);
    
    // Print a counter to show the system is running
    print_string("System Status: Running", 
                 (VGA_COLOR_YELLOW << 4) | VGA_COLOR_BLACK);
    print_char('\n', 0);
    
    int counter = 0;
    while (1) {
        // Move cursor to a specific position for the counter
        cursor_x = 0;
        cursor_y = 8;
        
        print_string("Counter: ", 
                     (VGA_COLOR_WHITE << 4) | VGA_COLOR_BLACK);
        print_number(counter, (VGA_COLOR_WHITE << 4) | VGA_COLOR_BLACK);
        print_string("     ", 0); // Clear any remaining digits
        
        counter++;
        delay(1000); // Simple delay
        
        // Prevent counter overflow
        if (counter > 9999) {
            counter = 0;
        }
    }
}
