#!/bin/bash

# Test script for Simple OS
echo "Building Simple OS..."
make clean
make all

echo "Starting QEMU with Simple OS..."
echo "Press Ctrl+A then X to exit QEMU"
echo ""

# Run QEMU with the OS
qemu-system-i386 \
    -drive file=build/os.img,format=raw,if=floppy \
    -monitor stdio \
    -display curses \
    -no-reboot \
    -no-shutdown
